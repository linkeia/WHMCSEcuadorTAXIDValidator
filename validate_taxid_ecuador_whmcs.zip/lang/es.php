<?php

return [
    'moduleTitle' => 'Validación de TAX ID de Ecuador',
    'importantMessage' => 'Para que este módulo funcione correctamente, es necesario que el soporte para TAX ID e impuestos esté habilitado en tu sistema WHMCS.',
    'activateValidation' => 'Activar/Desactivar Validación',
    'masterOptionDescription' => 'Esta opción principal activa o desactiva todas las funciones del módulo.',
    'enableDuplicateValidation' => 'Activar validación de TAX ID duplicado',
    'duplicateValidationDescription' => 'Al activar esta opción, el sistema verificará si el TAX ID ingresado ya existe en la base de datos y mostrará un error en caso de duplicados.',
    'saveChanges' => 'Guardar Cambios',
    'validationEnabled' => 'Validación activa',
    'validationDisabled' => 'Validación desactivada',
];
