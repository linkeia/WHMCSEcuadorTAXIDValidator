<?php

return [
    'moduleTitle' => 'Validação de TAX ID do Equador',
    'importantMessage' => 'Para que este módulo funcione corretamente, o suporte a TAX ID e impostos deve estar ativado no sistema WHMCS.',
    'activateValidation' => 'Ativar/Desativar Validação',
    'masterOptionDescription' => 'Esta opção principal ativa ou desativa todas as funções do módulo.',
    'enableDuplicateValidation' => 'Ativar validação de TAX ID duplicado',
    'duplicateValidationDescription' => 'Quando esta opção está ativada, o sistema verifica se o TAX ID inserido já existe no banco de dados e exibe um erro caso haja duplicatas.',
    'saveChanges' => 'Salvar Alterações',
    'validationEnabled' => 'Validação ativada',
    'validationDisabled' => 'Validação desativada',
];
