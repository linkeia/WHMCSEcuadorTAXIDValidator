<?php

return [
    'moduleTitle' => 'Ecuador TAX ID Validation',
    'importantMessage' => 'For this module to work properly, TAX ID and tax support must be enabled in your WHMCS system.',
    'activateValidation' => 'Enable/Disable Validation',
    'masterOptionDescription' => 'This master option enables or disables all module functions.',
    'enableDuplicateValidation' => 'Enable duplicate TAX ID validation',
    'duplicateValidationDescription' => 'When this option is enabled, the system will check if the entered TAX ID already exists in the database and display an error if duplicates are found.',
    'saveChanges' => 'Save Changes',
    'validationEnabled' => 'Validation enabled',
    'validationDisabled' => 'Validation disabled',
];
